            <nav>
                <ul>
                    <li><a href="#" title="About my studies"> <img src="img/Study.jpg"> </a></li>
                    <li><a href="#" title="My portfolio "><img src="img/portf.jpg"></a></li>
                    <li><a href="#" title="My articles "> <img src="img/articles.jpg"> </a></li>
                    <li><a href="#" title="Links "> <img src="img/link.jpg"> </a></li>
                    <li><a href="#" title="Contacts "> <img src="img/Contact.jpg"> </a></li>
                </ul>
            </nav>