

<?php 
 $p = 'Добро пожаловать на мою страничку!';
?>

<?php 
 $name = 'Алекс';
 $surname = 'Петров';
 $city = 'Питер';
 $age = 51;
?>


<?php
include 'main.php';
?>

