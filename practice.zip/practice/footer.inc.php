<div class="footer">
            <h3>Мы изучили базовые основы PHP! </h3>
        </div>